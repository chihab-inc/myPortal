#!/bin/sh

# Run the index.js file with Node.js
./node/node-darwin index.js