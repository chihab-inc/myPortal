#!/bin/sh

# Run the index.js file with Node.js
./node/node-linux index.js